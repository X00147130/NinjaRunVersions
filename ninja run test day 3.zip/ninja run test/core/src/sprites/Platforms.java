//package sprites;
//
//import com.badlogic.gdx.graphics.Texture;
//import com.badlogic.gdx.math.Rectangle;
//import com.badlogic.gdx.math.Vector2;
//
//import java.util.Random;
//
//public class Platforms {
//    //Constants
//    private static final int FLUCTUATION = 130;
//    public static final int PLATFORM_WIDTH = 500;
//
//    //Variables
//    private Texture platform;
//    private Vector2 posPlatform;
//    private Rectangle boundsPlatform;
//    private Random rand;
//
//    //Constructor
//    public Platforms(float x, float y) {
//        platform = new Texture("planks.png");
//        rand = new Random(140);
//        posPlatform = new Vector2(x, y + rand.nextInt(FLUCTUATION));
//        boundsPlatform = new Rectangle((int) posPlatform.x, (int) posPlatform.y, (float) platform.getWidth() / 2, platform.getHeight());
//    }
//
//    //Getters
//
//    public Texture getPlatform() {
//        return platform;
//    }
//
//    public Vector2 getPosPlatform() {
//        return posPlatform;
//    }
//
//    //Methods
//    public void platformPosition(float x, float y){
//        posPlatform.set(x,y);
//        boundsPlatform.setPosition(posPlatform.x, posPlatform.y);
//    }
//
//    //Clean Up
//    public void dispose(){
//        platform.dispose();
//    }
//}

