package sprites;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.math.Rectangle;
import com.dean.game.NinjaRun;

public class Ninja {
    //Constants
    private static final int CEILING = 345;
    private static final int MOVEMENT = 150;
    private static final int GRAVITY = -15;

    //Variables
    private Vector3 position;
    private Vector3 velocity;
    private Rectangle bounds;
    private Rectangle jumpBounds;

    //running animation
    private Animation ninjaAnimation;
    private Texture run;

    //jumping animation
    private Texture jumping;
    private Animation jumpAnimation;
    private boolean jumped;

    //jump sounds
    private Sound jump;

    //Constructor
    public Ninja(int x, int y){
        //movement and positioning
        position = new Vector3(x, y, 0);
        velocity = new Vector3(0,0,0);

        //running animation + bounds
        run = new Texture("ninjaAnimation.png");
        ninjaAnimation = new Animation( new TextureRegion(run), 6, 0.4f);
        bounds = new Rectangle(x, y, (float)run.getWidth() / 10, run.getHeight());

        //jumping animation
        jumping = new Texture("JumpAnimation.png");
        jumpAnimation = new Animation(new TextureRegion(jumping), 7, 0.5f);
        jumpBounds = new Rectangle(x, y, (float)run.getWidth() / 20, run.getHeight());
        jumped = false;

        //sounds
        jump = Gdx.audio.newSound(Gdx.files.internal("277212__thedweebman__8-bit-jump.wav"));
    }

    //Methods
    public void update(float dt){
        ninjaAnimation.update(dt);
        jumpAnimation.update(dt);
        if(position.y > 0) {
            velocity.add(0, GRAVITY, 0);
        }
        velocity.scl(dt);
        position.add(MOVEMENT * dt , velocity.y,0);

        if(position.y > CEILING)
            position.y = CEILING;

        if(position.y < 0) {
            position.y = 0;
        }
        velocity.scl(1/dt);
        bounds.setPosition(position.x, position.y);
        jumpBounds.setPosition(position.x, position.y);

    }

    public void jump(){
            velocity.y = 550;
            jump.play(0.3f);
    }

    //Getters
    public TextureRegion getTexture() {
        return ninjaAnimation.getFrame();
    }

    public TextureRegion getJumpingTexture(){
        return jumpAnimation.getFrame();
    }

    public boolean getJumped(){
        return jumped;
    }

    public Vector3 getPosition() {
        return position;
    }

    public Rectangle getBounds(){
        return bounds;
    }


    //setters
    public void setJumped(boolean jumped){
        this.jumped = jumped;
    }

    //Clean Up
    public void dispose(){
        run.dispose();
        jumping.dispose();
        jump.dispose();
    }
}
