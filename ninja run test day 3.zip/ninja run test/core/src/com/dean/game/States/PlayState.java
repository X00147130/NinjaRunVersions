package com.dean.game.States;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Array;
import com.dean.game.NinjaRun;
import sprites.Ninja;
//import sprites.Platforms;
import sprites.Spike;


public class PlayState extends State {
    //Spikes
    private static final int SPIKE_SPACING = 125;
    private static final int SPIKE_COUNT = 3;
    private Array<Spike> spikes;

    //Platforms
//    private static final int PLATFORM_COUNT = 2;
//    private static final int PLATFORM_DISTANCE = 40;
//    private Array<Platforms> floor;

    //variables
    private Ninja ninja;
    private Texture bg;
    private Music death;


    //Constructor
    public PlayState(GameStateManager gsm ){
        super(gsm);
        ninja = new Ninja(0,0);
        cam.setToOrtho(false, (float)NinjaRun.WIDTH /2, (float)NinjaRun.HEIGHT /2);
        bg = new Texture("bg3.png");
        death = Gdx.audio.newMusic(Gdx.files.internal("Dying-SoundBible.com-1255481835.mp3"));

        spikes = new Array<Spike>();
        for(int i = 1; i <= SPIKE_COUNT; i++ ){
            spikes.add(new Spike(i * (SPIKE_SPACING + Spike.SPIKE_WIDTH)));
        }

//        floor = new Array<Platforms>();
//        for(int i = 1; i <= PLATFORM_COUNT; i++){
//            floor.add(new Platforms(0,i * (PLATFORM_DISTANCE + Platforms.PLATFORM_WIDTH)));
//        }


    }

    //methods
    @Override
    protected void handleInput() {
        if (Gdx.input.justTouched()) {
            ninja.jump();
            ninja.setJumped(true);
        }
    }

    @Override
    public void update(float dt) {
        handleInput();
        ninja.update(dt);
        cam.position.x = ninja.getPosition().x + 80;

        //spikes
        for (int i = 0; i < spikes.size; i++) {
            Spike spike = spikes.get(i);

            if (cam.position.x - (cam.viewportWidth / 2) > spike.getPosSpikes().x + spike.getSpikes().getWidth()) {
                spike.reposition(spike.getPosSpikes().x + ((Spike.SPIKE_WIDTH + SPIKE_SPACING) * SPIKE_COUNT));
            }

            if (spike.collides(ninja.getBounds())) {
                death.setVolume(0.6f);
                death.play();
                gsm.set(new EndGameScreen(gsm));
            }
        }
        //platforms
//        for (int p = 0; p < floor.size; p++) {
//            Platforms platforms = floor.get(p);
//
//            if (cam.position.x - (cam.viewportWidth / 2) > platforms.getPosPlatform().x + platforms.getPlatform().getWidth()) {
//                floor.platformPosition(floor.getPosPlatform().x + ((Platform.PLATFORM_WIDTH + PLATFORM_DISTANCE) * PLATFORM_COUNT));
//            }
            cam.update();
        }


        @Override
        public void render (SpriteBatch sb){
            sb.setProjectionMatrix(cam.combined);
            sb.begin();
            sb.draw(bg, cam.position.x - (cam.viewportWidth / 2), 0);
            for (Spike spike : spikes) {
                sb.draw(spike.getSpikes(), spike.getPosSpikes().x, spike.getPosSpikes().y);
            }
//            for (Platforms platforms : floor) {
//                sb.draw(floor.getPlatforms(), floor.getPosPlatforms().x, floor.getPosPlatforms().y);
//            }
            if (ninja.getJumped() == true) {
                sb.draw(ninja.getJumpingTexture(), ninja.getPosition().x, ninja.getPosition().y);
            } else {
                sb.draw(ninja.getTexture(), ninja.getPosition().x, ninja.getPosition().y);
            }
            sb.end();
        }

        //Clean Up
        @Override
        public void dispose () {
            for (Spike spike : spikes) {
                spike.dispose();
                System.out.println("Spikes disposed");
            }

//            for (Platforms platforms : floor) {
//                floor.dispose();
//                System.out.println("Platforms disposed");
//            }

            bg.dispose();
            ninja.dispose();

        }
}


