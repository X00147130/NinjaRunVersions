package com.dean.game.States;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.dean.game.NinjaRun;
import com.badlogic.gdx.audio.Music;

public class EndGameScreen extends State {
    private Texture endBackground;
    private Texture endScreen;
    private Music gameOver;

    protected EndGameScreen(GameStateManager gsm) {
        super(gsm);
        cam.setToOrtho(false, (float)NinjaRun.WIDTH /2, (float)NinjaRun.HEIGHT /2);
        endBackground = new Texture("failed.png");
        endScreen = new Texture("dead.png");
        gameOver = Gdx.audio.newMusic(Gdx.files.internal("Gewitter__Thunderstorm-Tim-1509815136.mp3"));
        gameOver.setVolume(0.4f);
        gameOver.setLooping(false);
        gameOver.play();
    }

    @Override
    protected void handleInput() {
        if(Gdx.input.justTouched()) {
            gsm.set(new MenuState(gsm));
        }
        if(Gdx.input.justTouched()) {
            gameOver.stop();
        }
    }

    @Override
    public void update(float dt) {
        handleInput();
        cam.update();
    }

    @Override
    public void render(SpriteBatch sb) {
        sb.setProjectionMatrix(cam.combined);
        sb.begin();
        sb.draw(endBackground,0,0);
        sb.draw(endScreen, cam.position.x - (float)endScreen.getWidth() / 2, cam.position.y);
        sb.end();
    }

    @Override
    public void dispose() {
        endBackground.dispose();
        endScreen.dispose();
        gameOver.dispose();
        System.out.println("Death Screen Disposed");
    }
}
