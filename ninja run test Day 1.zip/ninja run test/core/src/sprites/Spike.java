package sprites;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector2;

import com.badlogic.gdx.math.Rectangle;
import java.util.Random;

public class Spike {
    private static final int Y = 0;
    private static final int SPIKE_GAP = 10;
    private static final int FLUCTUATION = 70;
    public static final int SPIKE_WIDTH = 40;
    private Texture spikes;
    private Vector2 posSpikes;
    private Rectangle boundsSpikes;
    private Random rand;

    public Spike(float x){
        spikes = new Texture("stump.png");
        rand = new Random();

        posSpikes = new Vector2(x * rand.nextInt(FLUCTUATION) + SPIKE_GAP, Y);

        boundsSpikes= new Rectangle((int) posSpikes.x,(int) posSpikes.y, spikes.getWidth(), spikes.getHeight());
    }

    public Texture getSpikes() {
        return spikes;
    }


    public Vector2 getPosSpikes() {
        return posSpikes;
    }

    public void reposition(float x){
        posSpikes.set(x, Y);
        boundsSpikes.setPosition(posSpikes.x, posSpikes.y);

    }
    public boolean collides( Rectangle player){
        return player.overlaps(boundsSpikes);
    }

    public void dispose(){
        spikes.dispose();
    }
}
