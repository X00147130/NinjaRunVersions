package com.dean.game.States;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.dean.game.NinjaRun;

/*
 *Created by deanc on 15/09/2020.
 */

public class MenuState extends State {
    private Texture menuBackground;
    private Texture playBtn;

    public MenuState(GameStateManager gsm){
        super(gsm);
        cam.setToOrtho(false, (float)NinjaRun.WIDTH /2, (float)NinjaRun.HEIGHT /2);
        menuBackground = new Texture("bg3.png");
        playBtn = new Texture("play.png");
    }

    @Override
    public void handleInput() {
        if (Gdx.input.justTouched())
            gsm.set(new PlayState(gsm));
    }

    @Override
    public void update (float dt){
        handleInput();
    }

    @Override
    public void render (SpriteBatch sb){
        sb.setProjectionMatrix(cam.combined);
        sb.begin();
        sb.draw(menuBackground, 0,0);
        sb.draw(playBtn, cam.position.x - (float)playBtn.getWidth() / 2, cam.position.y);
        sb.end();
    }

    @Override
    public void dispose(){
        menuBackground.dispose();
        playBtn.dispose();
        System.out.println("Menu State Disposed");
        System.out.println(" NINJA RUN ");
        System.out.println("Ronin by yoitrax | https://soundcloud.com/yoitrax\n" +
                "Music promoted by https://www.free-stock-music.com\n" +
                "Creative Commons Attribution 3.0 Unported License\n" +
                "https://creativecommons.org/licenses/by/3.0/deed.en_US");
    }
}
