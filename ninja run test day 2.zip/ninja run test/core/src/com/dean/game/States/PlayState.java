package com.dean.game.States;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Array;
import com.dean.game.NinjaRun;
import sprites.Ninja;
import sprites.Spike;


public class PlayState extends State {
    private static final int SPIKE_SPACING = 125;
    private static final int SPIKE_COUNT = 3;

    private Ninja ninja;
    private Texture bg;
    private Music death;

    private Array<Spike> spikes;

    //Constructor
    public PlayState(GameStateManager gsm ){
        super(gsm);
        ninja = new Ninja(0,0);
        cam.setToOrtho(false, (float)NinjaRun.WIDTH /2, (float)NinjaRun.HEIGHT /2);
        bg = new Texture("bg3.png");
        death = Gdx.audio.newMusic(Gdx.files.internal("Dying-SoundBible.com-1255481835.mp3"));

        spikes = new Array<Spike>();
        for(int i = 1; i <= SPIKE_COUNT; i++ ){
            spikes.add(new Spike(i * (SPIKE_SPACING + Spike.SPIKE_WIDTH)));
        }
    }

    //methods
    @Override
    protected void handleInput() {
        if (Gdx.input.isTouched())
            ninja.jump();
    }

    @Override
    public void update(float dt) {
        handleInput();
        ninja.update(dt);
        cam.position.x = ninja.getPosition().x + 80;

        for (int i = 0; i < spikes.size; i++) {
            Spike spike = spikes.get(i);

            if (cam.position.x - (cam.viewportWidth / 2) > spike.getPosSpikes().x + spike.getSpikes().getWidth()) {
                spike.reposition(spike.getPosSpikes().x + ((Spike.SPIKE_WIDTH + SPIKE_SPACING) * SPIKE_COUNT));
            }

            if(spike.collides(ninja.getBounds())) {
                death.setVolume(0.6f);
                death.play();
                gsm.set(new EndGameScreen(gsm));
            }
        }
        cam.update();
    }

    @Override
    public void render(SpriteBatch sb) {
        sb.setProjectionMatrix(cam.combined);
        sb.begin();
        sb.draw(bg, cam.position.x - (cam.viewportWidth /2), 0);
        for(Spike spike : spikes) {
            sb.draw(spike.getSpikes(), spike.getPosSpikes().x, spike.getPosSpikes().y);
        }
        sb.draw(ninja.getTexture(), ninja.getPosition().x, ninja.getPosition().y);
        sb.end();
    }

    //Clean Up
    @Override
    public void dispose() {
        for(Spike spike :spikes){
            spike.dispose();
            System.out.println("Play State disposed");
        }
        bg.dispose();
        ninja.dispose();

    }
}

