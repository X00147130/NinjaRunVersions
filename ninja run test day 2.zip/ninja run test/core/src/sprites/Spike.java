package sprites;

//Imports
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Rectangle;
import java.util.Random;

public class Spike {

    //Constants
    private static final int Y = 0;
    private static final int FLUCTUATION = 130;
    public static final int SPIKE_WIDTH = 60;

    //Variables
    private Texture spikes;
    private Vector2 posSpikes;
    private Rectangle boundsSpikes;
    private Random rand;

    //Constructor
    public Spike(float x){
        spikes = new Texture("Spikes.png");
        rand = new Random(140);
        posSpikes = new Vector2(x + rand.nextInt(FLUCTUATION), Y);
        boundsSpikes= new Rectangle((int) posSpikes.x,(int) posSpikes.y, spikes.getWidth() /2, spikes.getHeight());
    }

    //Getters
    public Texture getSpikes() {
        return spikes;
    }


    public Vector2 getPosSpikes() {
        return posSpikes;
    }

    //Methods
    public void reposition(float x){
        posSpikes.set(x, Y);
        boundsSpikes.setPosition(posSpikes.x, posSpikes.y);
    }
    public boolean collides(Rectangle player){
        return player.overlaps(boundsSpikes);
    }

    //Clean Up
    public void dispose(){
        spikes.dispose();
    }
}
