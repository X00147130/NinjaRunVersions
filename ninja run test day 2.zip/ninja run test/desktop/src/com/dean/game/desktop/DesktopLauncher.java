package com.dean.game.desktop;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.dean.game.NinjaRun;

public class DesktopLauncher {
	public static void main (String[] arg) {
		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
		config.width = NinjaRun.WIDTH;
		config.height = NinjaRun.HEIGHT;
		config.title = NinjaRun.TITLE;
		new LwjglApplication(new NinjaRun(), config);
	}
}
